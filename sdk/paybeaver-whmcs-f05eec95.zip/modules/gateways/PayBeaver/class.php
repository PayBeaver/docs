<?php

/**
 * Created by PayBeaver <merchant.paybeaver.com>
 * Version: 2020-12-07
 */

class PayBeaver {
    private $appId;
	private $appSecret;
	private $gatewayUri;

	public function __construct($appId, $appSecret, $url) {
	    $this->appId = $appId;
		$this->appSecret = $appSecret;
		$this->gatewayUri = $url . '/v1/gateway/fetch';
	}

	public function buildQuery($data) {
		unset($data['sign']);
		ksort($data);
		return http_build_query($data);
	}

	public function sign($data) {
		$signature = md5($data.$this->appSecret);
		return $signature;
	}

	public function verify($data, $signature) {
		return $this->sign($data) == $signature;
	}

    public function post($data) {
        $curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $this->gatewayUri);
		curl_setopt($curl, CURLOPT_HEADER, 0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		$data = curl_exec($curl);
		curl_close($curl);
		return json_decode($data, true);
    }

    public function buildHtml($params, $method = 'post', $target = '_self'){
		$html = "<form id='submit' name='submit' action='".$this->gatewayUri."' method='$method' target='$target'>";
		foreach ($params as $key => $value) {
			$html .= "<input type='hidden' name='$key' value='$value'/>";
		}
		$html .= "</form><script>document.forms['submit'].submit();</script>";
		return $html;
    }
}
