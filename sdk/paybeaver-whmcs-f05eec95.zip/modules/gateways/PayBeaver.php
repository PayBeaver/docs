<?php

/**
 * Created by PayBeaver <merchant.paybeaver.com>
 * Version: 2020-12-07
 */

function payBeaver_config() {
  $configarray = [
    "FriendlyName" 		    => ["Type" => "System", "Value"=>"在线支付（PayBeaver）"],
    "appId" 			        => ["FriendlyName" => "AppID", "Type" => "text", "Size" => "32", ],
    "appSecret" 		      => ["FriendlyName" => "AppSecret", "Type" => "text", "Size" => "32", ],
    "paybeaverUrl" 				=> ["FriendlyName" => "PayBeaverURL", "Type" => "text", "Size" => "64", ],
  ];
  return $configarray;
}

function payBeaver_link($params) {
  $systemurl = $params['systemurl'];
  if (!stristr($_SERVER['PHP_SELF'], 'viewinvoice')) {
    return;
  }

  include_once("PayBeaver/class.php");
  $payBeaver = new PayBeaver($params['appId'], $params['appSecret'], $params['paybeaverUrl']);
  $payData = [
    'app_id'        => $params['appId'],
    'out_trade_no'  => $params['invoiceid'],
    'total_amount'  => $params['amount'] * 100,
    'notify_url'    => $systemurl . "/modules/gateways/PayBeaver/notify.php",
    'return_url'    => $systemurl . "/viewinvoice.php?id=" . $params['invoiceid'],
  ];
  $payData['sign'] = $payBeaver->sign($payBeaver->buildQuery($payData));

  $response = $payBeaver->post($payData);
  logModuleCall('payBeaver', 'pay', '', json_encode($response));
  $webpaylink = $response['data']['pay_url'];

	return <<<HTML
<a href="{$webpaylink}" target="_blank" id="alipayDiv" class="btn btn-info btn-block">前往收银台</a>
<script>
const intervalID = setInterval(load, 5000);
function load() {
  const xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState === 4 && xmlhttp.status === 200 && xmlhttp.responseText === "SUCCESS") {
      document.getElementById("alipayDiv").innerHTML="支付成功";
      clearInterval(intervalID);
      window.location.reload();
    }

    xmlhttp.open("get","{$systemurl}/modules/gateways/PayBeaver/query.php?invoiceid={$params['invoiceid']}", true);
    xmlhttp.send();
  }
}
</script>
HTML;
}
