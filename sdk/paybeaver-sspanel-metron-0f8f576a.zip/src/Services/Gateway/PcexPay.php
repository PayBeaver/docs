<?php

/**
 * Created by PayBeaver <merchant.paybeaver.com>
 * Version: 2020-12-06
 */

namespace App\Services\Gateway;

use App\Services\Auth;
use App\Services\Gateway\PcexPay\AlipaySubmit;
use App\Services\Gateway\PcexPay\AlipayNotify;
use App\Models\Paylist;

class PcexPay extends AbstractPayment
{

    public function isHTTPS()
    {
        define('HTTPS', false);
        if (defined('HTTPS') && HTTPS) {
            return true;
        }
        if (!isset($_SERVER)) {
            return false;
        }
        if (!isset($_SERVER['HTTPS'])) {
            return false;
        }
        if ($_SERVER['HTTPS'] === 1) {  //Apache
            return true;
        }

        if ($_SERVER['HTTPS'] === 'on') { //IIS
            return true;
        }

        if ($_SERVER['SERVER_PORT'] == 443) { //其他
            return true;
        }
        return false;
    }

    public function MetronPay($type, $price, $shopinfo, $paylist_id=0)
    {
        if ($paylist_id==0 && $price < 1) {
            return ['ret' => 0, 'msg' => "金额需大于 1 元"];
        }

        if ( isset($shopinfo['telegram']) ) {
            $user = $shopinfo['telegram']['user'];
        } else {
            $user = Auth::getUser();
        }

        if ($paylist_id === 0) {
            $pl             = new Paylist();
            $pl->userid     = $user->id;
            $pl->total      = $price;
            $pl->datetime   = time();
            $pl->tradeno    = self::generateGuid();
            if ($shopinfo) {
                if ( isset($shopinfo['telegram']) ) {
                    unset($shopinfo['telegram']['user']);
                }
                $pl->shop   = json_encode($shopinfo);
            }
            $pl->save();
        } else {
            $pl = Paylist::find($paylist_id);
            if ($pl->status === 1){
                return ['ret' => 0, 'msg' => "该订单已交易完成"];
            }
        }

        $alipay_config['partner'] = $_ENV['pcexpay_id'];
        $alipay_config['key']     = $_ENV['pcexpay_key'];

        $alipay_config['sign_type']     = strtoupper('MD5');    //签名方式 不需修改
        $alipay_config['input_charset'] = strtolower('utf-8');  //字符编码格式 目前支持 gbk 或 utf-8
        $alipay_config['transport']     = $this->isHTTPS() ? 'https' : 'http';  //访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
        $url = ($this->isHTTPS() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];

        $alipay_config['apiurl']  = $this->getApiURL($_ENV['pcexpay_id'], $pl->tradeno);
        if (! $alipay_config['apiurl']) {
            return ['ret' => 0, 'msg' => "获取支付地址出错，请联系管理员"];
        }

        $parameter = array(
                "pid"           => trim($alipay_config['partner']),
                "type"          => $type,
                "notify_url"	=> $url . '/payment/notify/pcexpay',
                "return_url"	=> $url . '/user/payment/return?tradeno='.$pl->tradeno,
                "out_trade_no"	=> $pl->tradeno,
                "name"	        => '话费充值',
                "money"	        => $pl->total,
                "sitename"	    => $_ENV['appName']
        );

        $alipaySubmit = new AlipaySubmit($alipay_config);
        $url = $alipaySubmit->buildRequestForm($parameter);

        return ['ret' => 1, 'url' => $url, 'tradeno' => $pl->tradeno, 'type' => 'url'];
    }

    public function purchase($request, $response, $args) {
        return ['ret' => 0, 'msg' => "配置配置错误，请联系管理员"];
    }

    public function notify($request, $response, $args)
    {
        $alipayNotify = new AlipayNotify([
            'key'       => $_ENV['pcexpay_key'],
            'apiurl'    => '',
        ]);

        $verify_result = $alipayNotify->verifyNotify();

        if($verify_result) {//验证成功

            $out_trade_no = $request->getParam('out_trade_no');
            $trade_no     = $request->getParam('trade_no');

            $trade_status = $request->getParam('trade_status');     //交易状态
            $type         = $request->getParam('type');     //支付方式

            if ($trade_status == 'TRADE_SUCCESS') {
                switch ($type) {
                    case 'alipay':
                        $payment = "支付宝";
                        break;
                    case 'wxpay':
                        $payment = "微信";
                        break;
                    case 'qqpay':
                        $payment = 'qq钱包';
                        break;
                    default:
                        $payment = '蜂维易支付';
                        break;
                }
                $this->postPayment($out_trade_no, $payment);
                echo "success";		//请不要修改或删除
            }
        }
        else {
            //验证失败
            echo "fail";
        }
    }

    public function getPurchaseHTML()
    {
        return '
                        <div class="card-inner">
                        <p class="card-heading">请输入充值金额</p>
                        <form class="codepay" name="codepay" action="/user/code/codepay" method="get">
                            <input class="form-control maxwidth-edit" id="price" name="price" placeholder="输入充值金额后，点击你要付款的应用图标即可" autofocus="autofocus" type="number" min="0.01" max="1000" step="0.01" required="required">
                            <br>
                            <button class="btn btn-flat waves-attach" id="btnSubmit" type="submit" name="type" value="alipay" ><img src="/images/alipay.jpg" width="50px" height="50px" /></button>
                            <button class="btn btn-flat waves-attach" id="btnSubmit" type="submit" name="type" value="qqpay" ><img src="/images/qqpay.jpg" width="50px" height="50px" /></button>
                            <button class="btn btn-flat waves-attach" id="btnSubmit" type="submit" name="type" value="wxpay" ><img src="/images/weixin.jpg" width="50px" height="50px" /></button>

                        </form>
                        </div>
';
    }

    public function getReturnHTML($request, $response, $args) { }

    public function getStatus($request, $response, $args) { }

    protected function getApiURL($appID, $merchantOrderID) {
        return file_get_contents("https://api.paybeaver.com/api/v1/developer/epay/api-url?app_id={$appID}&merchant_order_id={$merchantOrderID}");
    }
}
